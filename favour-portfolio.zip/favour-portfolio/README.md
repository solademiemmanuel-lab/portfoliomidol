# Favour Jésùpémi — Brand Designer Portfolio

A single-page portfolio site for Favour Jésùpémi, brand designer.

## Structure

```
├── index.html       # All page content/sections
├── styles.css        # Design system (emerald + gold theme)
├── script.js         # Nav blur, mobile menu, portfolio filters, lightbox
└── assets/
    ├── logos/         # Brand identity / logo work
    ├── work/           # Flyers, campaigns, social posts
    └── testimonials/   # Client testimonial screenshots
```

## Running locally

No build step needed — plain HTML/CSS/JS. Just open `index.html` in a browser,
or serve the folder locally:

```
python3 -m http.server 8000
```

## Deploying to GitHub Pages

1. Push this folder to a GitHub repo.
2. Go to **Settings → Pages**.
3. Set source to the `main` branch, root folder.
4. Site will be live at `https://<username>.github.io/<repo-name>/`.

## Notes / to double-check before launch

- **Email**: the client's message had a garbled email ("Jésùpémi favour@gmail.com").
  I used `jesupemifavour@gmail.com` as a best guess — please confirm the exact
  address before pushing live.
- **LinkedIn**: the contact card has a placeholder `#` link for LinkedIn since no
  URL was provided — swap in the real profile link.
- Portfolio images are categorized as: Brand Identity, Campaigns & Flyers,
  Social Content, and Events & Community — filterable via the tabs above the gallery.
